-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 03:35 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vehicle_insurance`
--

-- --------------------------------------------------------

--
-- Table structure for table `accident`
--

CREATE TABLE `accident` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `accident_date` date NOT NULL,
  `accident_time` time NOT NULL,
  `accident_location` varchar(255) NOT NULL,
  `accident_description` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `added_by` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accident`
--

INSERT INTO `accident` (`id`, `vehicle_id`, `customer_id`, `accident_date`, `accident_time`, `accident_location`, `accident_description`, `created_at`, `updated_at`, `added_by`, `status`) VALUES
(4, 6, 2, '2022-05-22', '17:34:00', 'Matara', 'Hit by a bus', '2022-05-22 13:03:57', '2022-05-22 13:03:57', 1, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `role` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstName`, `lastName`, `username`, `password`, `email`, `phone`, `address`, `created_at`, `updated_at`, `role`, `profile_pic`) VALUES
(1, 'Sangeetha', 'W', 'danuka', '$2y$10$TxdAZbqgeaGIaFcmW6sISOy43Vq/z0cWjI7h43al/6FL6Pi/Dtpqu', 'sangeetha@gmail.com', '076123456', 'Galle', '2018-01-01 00:00:00', '2022-05-22 05:58:25', 'admin', '-628a1926964f57.61510849.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `added_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `firstName`, `lastName`, `username`, `password`, `email`, `phone`, `address`, `created_at`, `updated_at`, `added_by`) VALUES
(2, 'Jhon', 'Smith', 'smith', '$2y$10$.zfwi9zs9z5Tyjonwq4NwOtINVa2IEH2PyQyXcuGaE.OinaOgDRvW', 'jhonsmith@google.com', '0761234567', '149 New Chetty Street,\r\nColombo.', '2022-05-22 12:55:32', '2022-05-22 12:55:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(11) NOT NULL,
  `vehicle_no` varchar(255) NOT NULL,
  `vehicle_type` varchar(255) NOT NULL,
  `vehicle_model` varchar(255) NOT NULL,
  `vehicle_color` varchar(255) NOT NULL,
  `vehicle_chasis_no` varchar(255) NOT NULL,
  `vehicle_engine_no` varchar(255) NOT NULL,
  `vehicle_reg_date` date NOT NULL,
  `vehicle_reg_no` varchar(255) NOT NULL,
  `vehicle_reg_expiry` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `customer_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `vehicle_no`, `vehicle_type`, `vehicle_model`, `vehicle_color`, `vehicle_chasis_no`, `vehicle_engine_no`, `vehicle_reg_date`, `vehicle_reg_no`, `vehicle_reg_expiry`, `created_at`, `updated_at`, `customer_id`, `added_by`) VALUES
(6, '12345', 'SUV', 'Maruti Suzuki', 'Red', '123456', '123455', '2022-05-11', 'BGW - 1234', '2023-05-11', '2022-05-22 12:58:27', '0000-00-00 00:00:00', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_insurance`
--

CREATE TABLE `vehicle_insurance` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `insurance_type` varchar(255) NOT NULL,
  `insurance_policy_no` varchar(255) NOT NULL,
  `insurance_policy_expiry` date NOT NULL,
  `insurance_premium` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `added_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle_insurance`
--

INSERT INTO `vehicle_insurance` (`id`, `vehicle_id`, `customer_id`, `insurance_type`, `insurance_policy_no`, `insurance_policy_expiry`, `insurance_premium`, `created_at`, `updated_at`, `added_by`) VALUES
(6, 6, 2, 'Full', '123456', '2024-05-14', '150000', '2022-05-22 13:02:54', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_insurance_claim`
--

CREATE TABLE `vehicle_insurance_claim` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `accident_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `insurance_id` int(11) NOT NULL,
  `claim_amount` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `added_by` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle_insurance_claim`
--

INSERT INTO `vehicle_insurance_claim` (`id`, `vehicle_id`, `accident_id`, `customer_id`, `insurance_id`, `claim_amount`, `created_at`, `updated_at`, `added_by`, `status`) VALUES
(3, 6, 4, 2, 6, '56000', '2022-05-22 13:04:34', '2022-05-22 13:04:34', 1, 'pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accident`
--
ALTER TABLE `accident`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `added_by` (`added_by`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `added_by` (`added_by`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `added_by` (`added_by`);

--
-- Indexes for table `vehicle_insurance`
--
ALTER TABLE `vehicle_insurance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `added_by` (`added_by`);

--
-- Indexes for table `vehicle_insurance_claim`
--
ALTER TABLE `vehicle_insurance_claim`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `accident_id` (`accident_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `insurance_id` (`insurance_id`),
  ADD KEY `added_by` (`added_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accident`
--
ALTER TABLE `accident`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicle_insurance`
--
ALTER TABLE `vehicle_insurance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicle_insurance_claim`
--
ALTER TABLE `vehicle_insurance_claim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accident`
--
ALTER TABLE `accident`
  ADD CONSTRAINT `accident_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `accident_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `accident_ibfk_3` FOREIGN KEY (`added_by`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`added_by`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD CONSTRAINT `vehicle_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_ibfk_2` FOREIGN KEY (`added_by`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_insurance`
--
ALTER TABLE `vehicle_insurance`
  ADD CONSTRAINT `vehicle_insurance_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_ibfk_3` FOREIGN KEY (`added_by`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vehicle_insurance_claim`
--
ALTER TABLE `vehicle_insurance_claim`
  ADD CONSTRAINT `vehicle_insurance_claim_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_claim_ibfk_2` FOREIGN KEY (`accident_id`) REFERENCES `accident` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_claim_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_claim_ibfk_4` FOREIGN KEY (`insurance_id`) REFERENCES `vehicle_insurance` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicle_insurance_claim_ibfk_5` FOREIGN KEY (`added_by`) REFERENCES `admin` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
